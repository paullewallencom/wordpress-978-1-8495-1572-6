5726_06 - code notes

Three code files are included with this chapter:
They are as follows:

5726_06_01.txt
CSS for making images display responsively

5726_06_02.txt
Code for displaying images conditionally within the Loop

5726_06_03.txt
Code for displaying video from YouTube and making it responsive.

All of these files include commenting so the reader knows which part of the layout what code applies to. The code is also explained in the text.