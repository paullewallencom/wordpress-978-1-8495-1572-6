5726_06 - code notes

Three code files are included with this chapter:
They are as follows:

5726_06_01.txt
CSS to hide content from specific devices

5726_06_02.txt
Code to add new menus for mobile devices

5726_06_03.txt
CSS to style the new top menu on mobile devices

All of these files include commenting so the reader knows which part of the layout what code applies to. The code is also explained in the text.